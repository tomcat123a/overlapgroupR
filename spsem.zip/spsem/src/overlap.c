#include <R.h>
#include <Rinternals.h>
#include <math.h>
#include <Rdefines.h>
#include <R_ext/Rdynload.h>
#include <stdio.h>
#include <string.h>
#include "overlap.h"


void test(double* x,double* gap,double * penalty2, double *v,double* p,double* g,double* lambda1,double* lambda2,double* w,double *G,double *Y,
          double* maxIter,double* flag,double* tol
          ){
//x initialization,starting point,p vector;double b[p];x=&b;

//gap gap double * gap;

//penalty2 double a[5];penalty2 = &a;

//v double c[p];v=&c;

//p int

//g int

//lambda1 double

//lambda2 double

//w  matrix rownum=g,colnum=3,,3*g vector double*,[startindex,endindex,weight],w[0]=startindex[0],w[1]=endindex[0],..,
//w[3]=startindex[1]

//G  double* 1d array,G[w[0]]~~G[w[1]],w[2] group weight

//Y  zeros(length(G),1)

//maxIter int

//flag 0 or 1

//tol double  1e-6
 //printf("%f before overlapping", flag[0]);
 // printf("%f before overlapping", maxIter[0]);
  //Rprintf("Printing the matrix %f  \n\n",x[0]);
  overlapping(x, gap, penalty2,
              v,  (int)p[0], (int)g[0], lambda1[0], lambda2[0],
              w, G, Y, (int)maxIter[0], (int)flag[0],tol[0]);
}



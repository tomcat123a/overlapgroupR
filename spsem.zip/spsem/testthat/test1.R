library(spsem)
#(int)
p=length(dat$beta)

x=rep(2,p)
gap=0
penalty2=rep(0,5)
#(int)

lambda1=0.2
lambda2=0.2

v=runif(p)
v=rep(1,p)

w=dat$w

g=nrow(w)
G=dat$G
Y=rep(1, length(dat$G))
#(int)
maxIter=20
#(int)
flag=1
tol=1e-10



a=hello2(  x,  gap,  penalty2,  v,  p,  g,  lambda1,  lambda2,  w, G, Y,
                     maxIter, flag,  tol)
a[[1]]

# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Build and Reload Package:  'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

hello <- function() {
  print("Hello, world!")
}

##' @title hello2
##' @export
hello2 <- function(  x,  gap,  penalty2,  v,  p,  g,  lambda1,  lambda2,  w, G, Y,
                     maxIter, flag,  tol) {
  print(paste0('R',flag))
  .C("test", as.double(x), as.double(gap),  as.double(penalty2),  as.double(v),  as.double(p),  as.double(g),  as.double(lambda1),
  as.double(lambda2),  as.double(w), as.double(G), as.double(Y),
  as.double(maxIter), as.double(flag),  as.double(tol))
}






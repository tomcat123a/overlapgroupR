##' @useDynLib spsem, registration=TRUE
NULL
